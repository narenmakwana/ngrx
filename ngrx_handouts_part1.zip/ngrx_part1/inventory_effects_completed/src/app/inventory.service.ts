import {Injectable} from '@angular/core';
import {Observable} from "rxjs/Observable";
import {of} from "rxjs/observable/of";
import {_throw} from "rxjs/observable/throw";


@Injectable()
export class InventoryService {

    addProducts(quantity: number): Observable<number> {

        // An HTTP request to the server could go here

        if (quantity < 20) {
            return of(quantity);
        } else {
            return _throw("Refused: Too many products");
        }
    }
}