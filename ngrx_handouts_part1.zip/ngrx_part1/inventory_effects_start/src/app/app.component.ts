import { Component } from '@angular/core';
import {AddProduct} from './store/actions';
import {Store} from "@ngrx/store";

@Component({
    selector: 'app-root',
    template: `        
    <h2>Add products (ngrx)</h2>   
    <form #f="ngForm" (ngSubmit)="onSubmit(f.value)">
      Enter quantity: <input type="number" name="quantity" ngModel>
      <button type="submit">Add Products</button>
    </form>   
    `
})
export class AppComponent {

    constructor(private store: Store<any>) {}

    onSubmit({quantity}) {
        this.store.dispatch(new AddProduct({quantity: parseInt(quantity)}));

    }
}