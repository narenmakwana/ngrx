import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Store, select } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { Subscription } from 'rxjs/Subscription';

import { Product, ProductService } from '../../shared/services';
import {
  State,
  getProductsData,
  LoadAllProducts,
  LoadProductsByCategory,
} from '../store';

@Component({
  selector: 'nga-categories',
  styleUrls: [ './categories.component.scss' ],
  templateUrl: './categories.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CategoriesComponent implements OnDestroy {
  private readonly productsSubscription: Subscription;
  readonly categories$: Observable<string[]>;
  readonly products$: Observable<Product[]>;

  constructor(
    private productService: ProductService,
    private route: ActivatedRoute,
    private store: Store<State>
  ) {
    this.categories$ = this.productService.getAllCategories().pipe(
      map(categories => ['all', ...categories]));

    this.products$ = this.store.pipe(select(getProductsData));

    this.productsSubscription = this.route.params.subscribe(
      ({ category }) => this.getCategory(category)
    );
  }

  ngOnDestroy(): void {
    this.productsSubscription.unsubscribe();
  }

  private getCategory(category: string): void {
    return category.toLowerCase() === 'all'
      ? this.store.dispatch(new LoadAllProducts())
      : this.store.dispatch(new LoadProductsByCategory({ category: category.toLowerCase() }));
  }
}
