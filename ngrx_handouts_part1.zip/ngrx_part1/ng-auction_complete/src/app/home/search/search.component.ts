import { ChangeDetectionStrategy, Component, OnDestroy } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { Product } from '../../shared/services';
import { getProductsData, SearchProducts, State } from '../store';


@Component({
  selector: 'nga-search',
  styleUrls: [ './search.component.scss' ],
  templateUrl: './search.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SearchComponent implements OnDestroy {
  readonly products$: Observable<Product[]>;
  private readonly searchParamsSubscription: Subscription;

  constructor(private store: Store<State>) {
    this.products$ = this.store.pipe(select(getProductsData));

    this.searchParamsSubscription = this.store
      .pipe(select(state => state.search.params))
      .subscribe(params => this.store.dispatch(new SearchProducts({ params })));
  }

  ngOnDestroy() {
    this.searchParamsSubscription.unsubscribe();
  }
}
