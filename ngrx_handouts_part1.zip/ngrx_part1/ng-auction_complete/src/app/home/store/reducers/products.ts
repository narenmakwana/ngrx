import { Product } from '../../../shared/services';
import { ProductsActions, ProductsActionTypes } from '../actions';

export interface State {
  data: Product[];
  loadingError?: string;
}

export const initialState: State = {
  data: []
};

export function reducer(state = initialState, action: ProductsActions): State {
  switch (action.type) {
    case ProductsActionTypes.LoadSuccess: {
      return {
        ...state,
        data: action.payload.products,
        loadingError: undefined
      };
    }

    case ProductsActionTypes.LoadFailure: {
      return {
        ...state,
        data: [],
        loadingError: action.payload.error
      };
    }

    default: {
      return state;
    }
  }
}
