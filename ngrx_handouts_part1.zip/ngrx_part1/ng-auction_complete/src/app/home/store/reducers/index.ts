import { createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromProducts from './products';
import * as fromRoot from '../../../store';

export interface HomePageState {
  products: fromProducts.State;
}

export const reducers = {
  products: fromProducts.reducer
};

export interface State extends fromRoot.State {
  homePage: HomePageState;
}

export const getHomePageState = createFeatureSelector<HomePageState>('homePage');
export const getProductsState = createSelector(getHomePageState, state => state.products);
export const getProductsData = createSelector(getProductsState, state => state.data);
