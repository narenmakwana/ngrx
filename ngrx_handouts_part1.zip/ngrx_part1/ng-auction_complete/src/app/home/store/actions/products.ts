import { Action } from '@ngrx/store';
import { Product } from '../../../shared/services';

export enum ProductsActionTypes {
  LoadAll = '[Products] Load All',
  Search = '[Products] Search',
  LoadProductsByCategory = '[Products] Load Products By Category',
  LoadSuccess = '[Products] Load Success',
  LoadFailure = '[Products] Load Failure',
}

export class LoadAllProducts implements Action {
  readonly type = ProductsActionTypes.LoadAll;
}

export class LoadProductsByCategory implements Action {
  readonly type = ProductsActionTypes.LoadProductsByCategory;
  constructor(public readonly payload: { category: string }) {}
}

export class LoadProductsSuccess implements Action {
  readonly type = ProductsActionTypes.LoadSuccess;
  constructor(public readonly payload: { products: Product[] }) {}
}

export class LoadProductsFailure implements Action {
  readonly type = ProductsActionTypes.LoadFailure;
  constructor(public readonly payload: { error: string }) {}
}

export class SearchProducts implements Action {
  readonly type = ProductsActionTypes.Search;
  constructor(public readonly payload: { params: { [key: string]: any } }) {}
}

export type ProductsActions
  = LoadAllProducts
  | LoadProductsByCategory
  | LoadProductsSuccess
  | LoadProductsFailure
  | SearchProducts;
