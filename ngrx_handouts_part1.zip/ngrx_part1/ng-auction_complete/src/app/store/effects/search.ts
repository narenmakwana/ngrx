import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { map } from 'rxjs/operators';
import { Search, SearchActionTypes } from '../actions';

@Injectable()
export class SearchEffects {
  constructor(
    private readonly actions$: Actions,
    private readonly router: Router,
  ) {}

  @Effect({ dispatch: false })
  searchProducts$ = this.actions$
    .pipe(
      ofType<Search>(SearchActionTypes.Search),
      map(action => action.payload.params),
      map(params => this.router.navigate([ '/search' ], { queryParams: params }))
    );
}
